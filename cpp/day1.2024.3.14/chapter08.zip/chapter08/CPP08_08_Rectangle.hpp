/*
 * rectangle.hpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#ifndef CPP08_08_RECTANGLE_HPP_
#define CPP08_08_RECTANGLE_HPP_
#include <string>
#include <iostream>
using namespace std;
class Rectangle {
private:
	double width;
	double height;
	static int objectCount;
public:
	static int getObjectCount();
	Rectangle(void); //默认构造函数
	Rectangle(double _width, double _height); //带参构造函数
	Rectangle(const Rectangle &other); //拷贝构造函数
	Rectangle& operator =(const Rectangle &other);   // 赋值操作符
	void setWidth(double width) {
		this->width = width;
	}
	double getWidth() {
		return this->width;
	}
	void setHeight(double height);
	double getHeight();
	friend void setData(Rectangle &rect, double width, double height);
	friend ostream& operator<<(ostream &output, Rectangle &rect);
	~Rectangle(); //析构函数
	double area();
	double perimeter();
};
inline void Rectangle::setHeight(double height) {
	this->height = height;
}
inline double Rectangle::getHeight() {
	return this->height;
}
#endif /* CPP08_08_RECTANGLE_HPP_ */
