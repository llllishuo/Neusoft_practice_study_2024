/*
 * shape.hpp
 *
 *  Created on: 2021年8月5日
 *      Author: xiaojf
 */

#ifndef CPP08_12_SHAPE_HPP_
#define CPP08_12_SHAPE_HPP_
#include <iostream>
#include <string>
using namespace std;
struct Point {
	double x;
	double y;
	Point(double x = 0, double y = 0) :
			x(x), y(y) {
	}
	string toString();
	friend ostream& operator<<(ostream &output, Point &point);
};
class Shape {
public:
	Point center;
	string toString();
	void move(double dx = 0, double dy = 0);
	void moveTo(double x = 0, double y = 0);
	Shape(double x = 0, double y = 0);
	~Shape();
	friend ostream& operator<<(ostream &output, Shape &shape);
};

#endif /* CPP08_12_SHAPE_HPP_ */
