/*
 * hr.hpp
 *
 *  创建时间: 2021年8月7日
 *  代码编写: 肖俊峰
 */

#ifndef CPP08_19_EMP_HPP_
#define CPP08_19_EMP_HPP_
#include <string>
using namespace std;

namespace hr {

	class Emp {
	private:
		string name;
		string sex;
		int age;
	public:
		Emp(string, string, int);
		string toString();
	};
}
#endif /* CPP08_19_EMP_HPP_ */
