/*
 * rectangle.cpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#include "CPP08_05_Rectangle.hpp"

#include <iostream>
using namespace std;
Rectangle::Rectangle(void) :
		width(0), height(0) {
	cout << "Rectangle(void)" << endl;
}
Rectangle::Rectangle(double width, double height) :
		width(width), height(width) {
	cout << "Rectangle(double width, double height)" << endl;
}

Rectangle::Rectangle(const Rectangle &other) :
		width(other.width), height(other.width) {
	cout << "Rectangle(const Point &other)" << endl;
}
Rectangle& Rectangle::operator =(const Rectangle &other) {
	cout << "operator =(const Rectangle &other)" << endl;
	if (this != &other) {
		this->width = other.width;
		this->height = other.height;
	}
	return *this;
}

string Rectangle::toString(void) {
	string str("Rectangle[width=");
	str += to_string(width);
	str += ",height=";
	str += to_string(height);
	str += ",area()=";
	str += to_string(this->area());
	str += ",height=";
	str += to_string(this->perimeter());
	str += "]";
	return str;
}

Rectangle::~Rectangle() {
	cout << "~Rectangle()" << endl;
}
double Rectangle::area() {
	return width * height;
}
double Rectangle::perimeter() {
	return (width + height) * 2;
}

