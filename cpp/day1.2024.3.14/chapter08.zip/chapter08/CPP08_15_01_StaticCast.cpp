//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_15_Ellipse.hpp"
#include "CPP08_15_Rectangle.hpp"
using namespace std;
int main() {
	string *name = new string("Tom");
	Shape *shape = new Rectangle(8, 6);
	// 编译时检查，运行时不检查。
	//Rectangle *rect = (Rectangle*)shape;
	Rectangle *rect = static_cast<Rectangle*>(shape);
	cout << rect->getWidth() << endl;
	// 无法检查对象的实际类型是否与指针类型一致！
	Ellipse *elli = static_cast<Ellipse*>(shape);
	cout << elli->getMajorRadius() << endl;
	// 非父子关系可以检查出来。
	// rect = static_cast<Rectangle*>(elli);
	// 完全无关系可以检查出来。
	// rect = static_cast<Rectangle*>(name);
	delete shape;
	delete name;
	return 0;
}
