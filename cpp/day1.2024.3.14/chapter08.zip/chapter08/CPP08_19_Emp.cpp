/*
 * hr.cpp
 *
 *  创建时间: 2021年8月7日
 *  代码编写: 肖俊峰
 */
#include "CPP08_19_Emp.hpp"

hr::Emp::Emp(string name, string sex, int age) :
		name(name), sex(sex), age(age) {
}
string hr::Emp::toString() {
	return "Emp[name=" + name + ",sex=" + sex + ",age=" + to_string(age) + "]";
}
