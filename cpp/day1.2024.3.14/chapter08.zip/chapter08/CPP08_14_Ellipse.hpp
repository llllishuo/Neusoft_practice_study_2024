/*
 * ellipse.hpp
 *
 *  创建时间: 2021年8月5日
 *  代码编写: 肖俊峰
 */

#ifndef CPP08_14_ELLIPSE_HPP_
#define CPP08_14_ELLIPSE_HPP_

#include <string>
#include <iostream>

#include "CPP08_14_Shape.hpp"
using namespace std;
class Ellipse: public Shape {
private:
	double majorRadius;
	double minorRadius;
public:
	static const double PI;
	Ellipse(double majorRadius = 0, double minorRadius = 0);
	Ellipse(const Ellipse &other);
	Ellipse& operator =(const Ellipse &other);
	void setMajorRadius(double majorRadius) {
		this->majorRadius = majorRadius;
	}
	double getMajorRadius() {
		return this->majorRadius;
	}
	void setMinorRadius(double minorRadius);
	double getMinorRadius();
	string toString();
	friend ostream& operator<<(ostream &output, Ellipse &elli);
	~Ellipse();
	double area();
	double perimeter();
};
inline void Ellipse::setMinorRadius(double minorRadius) {
	this->minorRadius = minorRadius;
}
inline double Ellipse::getMinorRadius() {
	return this->minorRadius;;
}

#endif /* CPP08_14_ELLIPSE_HPP_ */
