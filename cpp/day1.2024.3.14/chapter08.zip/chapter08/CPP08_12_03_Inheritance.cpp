//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "CPP08_12_Rectangle.hpp"
#include "CPP08_12_Ellipse.hpp"
int main() {
	Shape *shape;
	shape = new Shape(3, 4);
	shape->move(2, 3);
	cout << *shape << endl;
	cout << shape->toString() << endl;
	delete shape;
	cout << endl;

	shape = new Rectangle(8, 6);
	shape->moveTo(20, 30);
	cout << *shape << endl;
	cout << shape->toString() << endl;
	delete shape;
	cout << endl;

	shape = new Ellipse(8, 6);
	shape->moveTo(40, 60);
	cout << *shape << endl;
	cout << shape->toString() << endl;
	delete shape;

	return 0;
}
