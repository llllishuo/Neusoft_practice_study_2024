//============================================================================
// Name        : CPP08_12_MultipleInheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
using namespace std;
class F1 {
protected:
	string name;
public:
	F1(string name) :
			name(name) {
	}
	void printName() {
		cout << name << endl;
	}
};
class F2 {
protected:
	string name;
public:
	F2(string name) :
			name(name) {
	}
	void printName() {
		cout << name << endl;
	}
};

class S: public F1, public F2 {
public:
	S(string name1, string name2) :
			F1(name1), F2(name2) {
	}
	void printName() {
		cout << F1::name << " , " << F2::name << endl;
		//cout << "Apple" << endl;
	}
};

int main() {
	S s("Tom", "John");
	//s.printName();
	s.F1::printName();
	s.F2::printName();
	s.printName();
}
