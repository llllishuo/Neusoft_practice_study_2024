//============================================================================
// Name        : CPP08_11_Lambda.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<string>
using namespace std;

int main() {
	auto intAdd = [](int a, int b) -> int {
		return a + b;
	};
	cout << intAdd(5, 4) << endl;
	auto lambda1 = []() -> string {
		return "hello world";
	};
	cout << lambda1() << endl;
	auto lambda2 = []() -> double {
		return 999.999;
	};
	cout << lambda2() << endl;
	return 0;
}
