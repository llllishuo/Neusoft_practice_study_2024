//============================================================================
// Name        : CPP08_03_Constructor.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_08_Rectangle.hpp"
using namespace std;

int main() {
	cout << Rectangle::getObjectCount() << endl;
	Rectangle rect1;
	cout << Rectangle::getObjectCount() << endl;
	{
		Rectangle rect2(9, 8);
		cout << Rectangle::getObjectCount() << endl;
	}
	cout << Rectangle::getObjectCount() << endl;
	Rectangle rect3(rect1);
	cout << Rectangle::getObjectCount() << endl;
	return 0;
}
