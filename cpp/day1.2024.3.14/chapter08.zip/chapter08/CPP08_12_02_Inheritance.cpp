//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "CPP08_12_Rectangle.hpp"
#include "CPP08_12_Ellipse.hpp"
int main() {

	Rectangle *prect = new Rectangle(8, 6);
	cout << prect->toString() << endl;
	prect->move(3, 2);
	cout << *prect << endl;
	prect->moveTo(30, 24);
	cout << *prect << endl;
	cout << prect->area() << endl;
	cout << prect->perimeter() << endl;
	delete prect;

	cout << endl;

	Ellipse *pelli = new Ellipse(4.3, 3.6);
	cout << pelli->toString() << endl;
	pelli->move(3, 2);
	cout << *pelli << endl;
	pelli->moveTo(30, 24);
	cout << *pelli << endl;
	cout << pelli->area() << endl;
	cout << pelli->perimeter() << endl;
	delete pelli;
	return 0;
}
