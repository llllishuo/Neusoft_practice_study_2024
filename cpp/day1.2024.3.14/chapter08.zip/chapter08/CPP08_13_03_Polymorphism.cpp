#include <iostream>

#include "CPP08_13_Ellipse.hpp"
#include "CPP08_13_Rectangle.hpp"
using namespace std;
int main() {
	Shape *shapes[] = {new Rectangle(8, 6), new Ellipse(8, 6) };
	double area = 0;
	for (Shape *shape : shapes) {
		area += shape->area();
	}
	cout<< "area=" << area << endl;
	for (Shape *shape : shapes) {
		delete shape;
	}
	return 0;
}

