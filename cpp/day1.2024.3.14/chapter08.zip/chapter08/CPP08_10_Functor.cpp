//============================================================================
// Name        : CPP12_04_Functor.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include<iostream>
#include<string>
using namespace std;

class Functor {
private:
	int n;
	string s;
public:
	Functor() :
			n(1), s("A") {
	}
	void operator()(string str) {
		cout << s << "," + str << endl;
	}
	int operator()(int num1, int num2) {
		return num1 + num2 + n;
	}
};

int main() {
	Functor functor;
	functor("hello world");
	int res = functor(1, 2);
	cout << res << endl;
	cout << Functor()(3, 4) << endl;
}
