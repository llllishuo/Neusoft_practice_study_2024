/*
 * dep.cpp
 *
 *  创建时间: 2021年8月7日
 *  代码编写: 肖俊峰
 */
#include "CPP08_19_Dep.hpp"
hr::Dep::Dep(string name) :
		name(name) {
}
string hr::Dep::toString() {
	return "Dep[name=" + name + "]";
}

