/*
 * shape.cpp
 *
 *  Created on: 2021年8月5日
 *      Author: xiaojf
 */
#include "CPP08_14_Shape.hpp"
string Point::toString() {
	string str;
	str += "Point";
	str += "[x=";
	str += to_string(x);
	str += ",y=";
	str += to_string(y);
	str += "]";
	return str;
}
ostream& operator<<(ostream &output, Point &point) {
	output << point.toString();
	return output;
}

Shape::Shape(double x, double y) :
		center(x, y) {
	cout << "Shape::Shape(double x, double y)" << endl;
}
Shape::~Shape() {
	cout << "Shape::~Shape()" << endl;
}
void Shape::move(double dx, double dy) {
	center.x += dx;
	center.y += dy;
}
void Shape::moveTo(double x, double y) {
	center.x = x;
	center.y = y;
}

string Shape::toString() {
	string str;
	str += "Shape";
	str += "[center=";
	str += center.toString();
	str += "]";
	return str;
}
ostream& operator<<(ostream &output, Shape &shape) {
	output << shape.toString();
	return output;
}

