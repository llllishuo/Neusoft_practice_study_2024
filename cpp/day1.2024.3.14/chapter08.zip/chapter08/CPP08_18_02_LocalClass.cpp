//============================================================================
// Name        : CPP08_14_02_LocalClass.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void func() {
	class LocalClass {
		string name;
	public:
		LocalClass(string name) :
				name(name) {
		}
		string getName() {
			return name;
		}
	};
	LocalClass lc("Tom");
	cout << lc.getName() << endl;
}
int main() {
	func();
	return 0;
}
