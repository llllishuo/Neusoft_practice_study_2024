/*
 * rectangle.hpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#ifndef CPP08_04_RECTANGLE_HPP_
#define CPP08_04_RECTANGLE_HPP_
#include <string>
class Rectangle {
public:
	double width;
	double height;
	Rectangle(void); //默认构造函数
	Rectangle(double _width, double _height); //带参构造函数
	Rectangle(const Rectangle &other); //拷贝构造函数
	Rectangle& operator =(const Rectangle &other);   // 赋值操作符
	std::string toString(void);
	~Rectangle(); //析构函数
	double area();
	double perimeter();
};

#endif /* CPP08_04_RECTANGLE_HPP_ */
