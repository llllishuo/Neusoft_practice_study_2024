//============================================================================
// Name        : CPP_12_01_AutoPtr.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstring>
#include <utility>
using namespace std;

int add(int x, int y) {
	return x + y;
}
int main() {
	const int num = 100;
	int a = 1, b = 2, c = 3;
	int x = a + b;
	int y = b + c;
	int &x1 = x;
	int p = add(x, y);

	int &&z1 = 23;
	int &&z2 = a + b + c;
	int &&z3 = add(x, y);
	z1 = 9;
	z2 = 99;
	z3 = 999;
	return 0;
}
