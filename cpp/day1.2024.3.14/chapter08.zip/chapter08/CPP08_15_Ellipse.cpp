/*
 * ellipse.cpp
 *
 *  创建时间: 2021年8月5日
 *  代码编写: 肖俊峰
 */
#include "CPP08_15_Ellipse.hpp"

#include <math.h>
const double Ellipse::PI = 3.1415926535897932;

Ellipse::Ellipse(double majorRadius, double minorRadius) :
		majorRadius(majorRadius), minorRadius(minorRadius) {
	cout << "Ellipse::Ellipse(double majorRadius, double minorRadius)" << endl;
}
Ellipse::Ellipse(const Ellipse &other) :
		majorRadius(other.majorRadius), minorRadius(other.minorRadius) {
	cout << "Ellipse::Ellipse(const Ellipse &other)" << endl;
}
Ellipse::~Ellipse() {
	cout << "Ellipse::~Ellipse()" << endl;
}
Ellipse& Ellipse::operator =(const Ellipse &other) {
	cout << "Ellipse::operator =(const Ellipse &other)" << endl;
	if (this != &other) {
		this->majorRadius = other.majorRadius;
		this->minorRadius = other.minorRadius;
	}
	return *this;
}
string Ellipse::toString() {
	string str;
	str += "Ellipse[";
	str += "center=";
	str += center.toString();
	str += ",majorRadius=";
	str += to_string(majorRadius);
	str += ",minorRadius=";
	str += to_string(minorRadius);
	str += ",area()=";
	str += to_string(area());
	str += ",perimeter()=";
	str += to_string(perimeter());
	str += "]";

	return str;
}
ostream& operator<<(ostream &output, Ellipse &elli) {
	output << elli.toString();
	return output;
}
double Ellipse::area() {
	cout << "Ellipse::area()" << endl;
	return PI * majorRadius * minorRadius;
}
double Ellipse::perimeter() {
	cout << "Ellipse::perimeter()" << endl;
	return 2 * PI * sqrt((majorRadius * majorRadius + minorRadius * minorRadius) / 2);
}
