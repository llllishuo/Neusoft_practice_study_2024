//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "CPP08_12_Rectangle.hpp"
#include "CPP08_12_Ellipse.hpp"
int main() {
	{
		Rectangle rect(8, 6);
		cout << rect << endl;
		rect.move(3, 2);
		cout << rect << endl;
		rect.moveTo(30, 24);
		cout << rect << endl;
		cout << rect.area() << endl;
		cout << rect.perimeter() << endl;
	}
	cout << endl;
	{
		Ellipse elli(4.3, 3.6);
		cout << elli << endl;
		elli.move(3, 2);
		cout << elli << endl;
		elli.moveTo(30, 24);
		cout << elli << endl;
		cout << elli.area() << endl;
		cout << elli.perimeter() << endl;
	}
	return 0;
}
