//============================================================================
// Name        : CPP08_03_Constructor.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_09_Rectangle.hpp"
using namespace std;

int main() {
	Rectangle rect1(4, 3);
	Rectangle rect2(8, 6);
	Rectangle rect3 = rect1 + rect2;
	cout << rect3 << endl;
	return 0;
}
