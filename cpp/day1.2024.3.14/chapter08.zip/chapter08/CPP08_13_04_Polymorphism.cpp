#include <iostream>

#include "CPP08_13_Ellipse.hpp"
#include "CPP08_13_Rectangle.hpp"
using namespace std;
int main() {
	//Shape shapes[3] = { Shape(3, 4), Rectangle(8, 6),Ellipse(8, 6) };
	Shape shapes[3];
	shapes[0] = Shape(3, 4); //赋值
	shapes[1] = Rectangle(8, 6); //赋值
	shapes[2] = Ellipse(8, 6); //赋值
	for (Shape shape : shapes) {
		cout << shape << endl;
	}
	return 0;
}

