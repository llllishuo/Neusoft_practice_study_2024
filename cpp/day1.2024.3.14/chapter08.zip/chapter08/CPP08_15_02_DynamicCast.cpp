//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_15_Ellipse.hpp"
#include "CPP08_15_Rectangle.hpp"
using namespace std;
int main() {
	string* name = new string("Tom");
	Shape *shape = new Rectangle(8, 6);
	// 编译时不检查运行时检查。
	Rectangle *rect = dynamic_cast<Rectangle*>(shape);
	cout << rect->getWidth() << endl;
	Ellipse *elli = dynamic_cast<Ellipse*>(shape);
	cout << (elli == nullptr) << endl;
	//cout << elli->getMajorRadius() << endl; // 运行时出错！
	//rect = dynamic_cast<Rectangle*>(elli);
	// 只有完全无关系才能检查出来。
	//rect = dynamic_cast<Rectangle*>(name);
	delete shape;
	delete name;
	return 0;
}
