//============================================================================
// Name        : CPP08_12_MultipleInheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
using namespace std;
class G {
protected:
	string name;
public:
	G(string name) :
			name(name) {
		cout << "G(string name)" << endl;
		cout << name << endl;
	}
	void printName() {
		cout << name << endl;
	}
};
class F1: virtual public G {
public:
	F1(string name) :
			G(name) {
		cout << "F1(string name)" << endl;
		cout << name << endl;
	}
	void printF1Name() {
		cout << name << endl;
	}
};
class F2: virtual public G {
public:
	F2(string name) :
			G(name) {
		cout << "F2(string name)" << endl;
		cout << name << endl;
	}
	void printF2Name() {
		cout << name << endl;
	}
};

class S: public F1, public F2 {
public:
	S(string name1, string name2) :
			G(name1 + "," + name2), F1(name1), F2(name2) {
		cout << "S(string name1, string name2)" << endl;
	}
};

int main() {
	S s("Tom", "John");
	s.printName();
	s.printF1Name();
	s.printF2Name();
	return 0;
}
