/*
 * rectangle.hpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#ifndef CPP08_13_RECTANGLE_HPP_
#define CPP08_13_RECTANGLE_HPP_
#include <string>
#include <iostream>

#include "CPP08_13_Shape.hpp"
using namespace std;
class Rectangle: public Shape {
private:
	double width;
	double height;
public:
	Rectangle(double width = 0, double height = 0);
	Rectangle(const Rectangle &other);
	Rectangle& operator =(const Rectangle &other);
	void setWidth(double width) {
		this->width = width;
	}
	double getWidth() {
		return this->width;
	}
	void setHeight(double height);
	double getHeight();
	string toString();
	friend ostream& operator<<(ostream &output, Rectangle &rect);
	~Rectangle();
	double area();
	double perimeter();
};
inline void Rectangle::setHeight(double height) {
	this->height = height;
}
inline double Rectangle::getHeight() {
	return this->height;
}
#endif /* CPP08_12_RECTANGLE_HPP_ */
