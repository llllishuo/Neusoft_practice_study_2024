//============================================================================
// Name        : CPP08_14_Namespaces.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_19_Dep.hpp"
#include "CPP08_19_Emp.hpp"
using namespace std;
int main() {
	hr::Emp emp("Tom", "male", 32);
	cout << emp.toString() << endl;
	hr::Dep dep("Marketing");
	cout << dep.toString() << endl;
	return 0;
}
