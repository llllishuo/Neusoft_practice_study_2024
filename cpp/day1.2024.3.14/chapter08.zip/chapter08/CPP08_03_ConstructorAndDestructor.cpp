//============================================================================
// Name        : CPP08_03_Constructor.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "CPP08_03_Rectangle.hpp"
using namespace std;
int main() {
	{
		Rectangle rect1;
		cout << "rect1 width = " << rect1.width << endl;
		cout << "rect1 height = " << rect1.height << endl;
		cout << "rect1 area = " << rect1.area() << endl;
		cout << "rect1 perimeter = " << rect1.perimeter() << endl;
	}
	cout << endl;
	{
		Rectangle rect2(8, 6);
		cout << "rect2 width = " << rect2.width << endl;
		cout << "rect2 height = " << rect2.height << endl;
		cout << "rect2 area = " << rect2.area() << endl;
		cout << "rect2 perimeter = " << rect2.perimeter() << endl;
	}
	return 0;
}
