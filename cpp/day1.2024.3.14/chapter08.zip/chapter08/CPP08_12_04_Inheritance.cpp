//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "CPP08_12_Rectangle.hpp"
#include "CPP08_12_Ellipse.hpp"
int main() {
	{
		Shape s1 = Shape(3, 4);
		cout << s1 << endl;
	}
	cout << endl;
	{
		Shape s2 = Rectangle(8, 6);
		cout << s2 << endl;
	}
	cout << endl;
	{
		Shape s3 = Ellipse(8, 6);
		cout << s3 << endl;
	}
	return 0;
}
