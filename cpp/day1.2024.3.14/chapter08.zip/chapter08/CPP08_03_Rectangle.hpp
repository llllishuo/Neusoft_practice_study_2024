/*
 * rectangle.hpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#ifndef CPP08_03_RECTANGLE_HPP_
#define CPP08_03_RECTANGLE_HPP_
class Rectangle {
public:
	double width;
	double height;
	Rectangle(); //默认构造函数
	Rectangle(double width, double height); //带参构造函数
	~Rectangle(); //析构函数
	double area();
	double perimeter();
};

#endif /* RECTANGLE_HPP_ */
