/*
 * rectangle.hpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#ifndef CPP08_02_RECTANGLE_HPP_
#define CPP08_02_RECTANGLE_HPP_
class Rectangle {
public:
	double width;
	double height;
	double area();
	double perimeter();
};

#endif /* RECTANGLE_HPP_ */
