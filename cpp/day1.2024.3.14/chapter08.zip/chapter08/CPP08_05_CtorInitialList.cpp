//============================================================================
// Name        : CPP08_03_Constructor.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_05_Rectangle.hpp"
using namespace std;
int main() {
	Rectangle rect1;
	rect1.width = 4;
	rect1.height = 3;
	Rectangle rect2(rect1);
	Rectangle rect3 = rect1;
	Rectangle rect4;
	rect4 = rect1;
	cout << "rect1 = " << rect1.toString() << endl;
	cout << "rect2 = " << rect2.toString() << endl;
	cout << "rect3 = " << rect3.toString() << endl;
	cout << "rect4 = " << rect4.toString() << endl;
	return 0;
}
