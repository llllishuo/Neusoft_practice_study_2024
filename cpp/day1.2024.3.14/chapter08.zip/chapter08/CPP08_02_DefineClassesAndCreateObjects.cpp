//============================================================================
// Name        : CPP08_02_DefineClassesAndCreateObjects.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "CPP08_02_Rectangle.hpp"
using namespace std;

int main() {
	Rectangle rect;
	cout << "rect width = " << rect.width << endl;
	cout << "rect height = " << rect.height << endl;
	cout << "rect area = " << rect.area() << endl;
	cout << "rect perimeter = " << rect.perimeter() << endl;
	cout << endl;
	rect.width = 8;
	rect.height = 6;
	cout << "rect width = " << rect.width << endl;
	cout << "rect height = " << rect.height << endl;
	cout << "rect area = " << rect.area() << endl;
	cout << "rect perimeter = " << rect.perimeter() << endl;
	return 0;
}
