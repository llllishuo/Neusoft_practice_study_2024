#include <iostream>

#include "CPP08_13_Ellipse.hpp"
#include "CPP08_13_Rectangle.hpp"
using namespace std;
int main() {
	Shape *shape;
//	shape = new Shape(3, 4);
//	shape->move(2, 3);
//	cout << *shape << endl;
//	cout << shape->toString() << endl;
//	delete shape;
//	cout << endl;

	shape = new Rectangle(8, 6);
	shape->moveTo(20, 30);
	cout << *shape << endl;
	cout << shape->toString() << endl;
	delete shape;
	cout << endl;

	shape = new Ellipse(8, 6);
	shape->moveTo(40, 60);
	cout << *shape << endl;
	cout << shape->toString() << endl;
	delete shape;

	return 0;
}




