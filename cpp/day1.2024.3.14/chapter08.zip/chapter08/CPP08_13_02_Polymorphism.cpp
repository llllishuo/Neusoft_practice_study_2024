#include <iostream>

#include "CPP08_13_Ellipse.hpp"
#include "CPP08_13_Rectangle.hpp"
using namespace std;
int main() {

	Shape *shapes[] = { new Shape(3, 4), new Rectangle(8, 6), new Ellipse(8, 6) };
	for (Shape *shape : shapes) {
		cout<< *shape << endl;
	}
	for (Shape *shape : shapes) {
		delete shape;
	}
	return 0;
}

