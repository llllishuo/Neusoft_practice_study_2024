//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_15_Ellipse.hpp"
#include "CPP08_15_Rectangle.hpp"
using namespace std;
int main() {
	const int i1 =9;
	int i2 = i1;
	const Shape *shape01 = new Rectangle(8, 6);
	//shape01->move(12, 12);
	Shape *shape02 = const_cast<Shape*>(shape01);
	shape02->move(12, 12);
	delete shape01;
	return 0;
}
