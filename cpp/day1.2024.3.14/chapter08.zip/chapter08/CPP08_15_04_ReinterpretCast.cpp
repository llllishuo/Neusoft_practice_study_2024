//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_15_Ellipse.hpp"
#include "CPP08_15_Rectangle.hpp"
using namespace std;
int main() {
	// 1.指针和整数之间的转换。
	// 2.不同类型的指针/成员指针/引用之间的转换。
	Shape *shape01 = new Rectangle(8, 6);
	cout << shape01 << endl;
	long long v = reinterpret_cast<long long>(shape01);
	cout << "0x" << hex << v << endl;
	delete shape01;
	return 0;
}
