/*
 * rectangle.cpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#include <iostream>

#include "CPP08_04_Rectangle.hpp"
using namespace std;
Rectangle::Rectangle(void) {
	cout << "Rectangle(void)" << endl;
	width = 0;
	height = 0;
}
Rectangle::Rectangle(double width, double height) {
	cout << "Rectangle(double width, double height)" << endl;
	this->width = width;
	this->height = height;
}

Rectangle::Rectangle(const Rectangle &other) {
	cout << "Rectangle(const Point &other)" << endl;
	this->width = other.width;
	this->height = other.height;
}
Rectangle& Rectangle::operator =(const Rectangle &other) {
	cout << "operator =(const Rectangle &other)" << endl;
	if (this != &other) {
		this->width = other.width;
		this->height = other.height;
	}
	return *this;
}

string Rectangle::toString(void) {
	string str("Rectangle[width=");
	str += to_string(width);
	str += ",height=";
	str += to_string(height);
	str += ",area()=";
	str += to_string(this->area());
	str += ",height=";
	str += to_string(this->perimeter());
	str += "]";
	return str;
}

Rectangle::~Rectangle() {
	cout << "~Rectangle()" << endl;
}
double Rectangle::area() {
	return width * height;
}
double Rectangle::perimeter() {
	return (width + height) * 2;
}

