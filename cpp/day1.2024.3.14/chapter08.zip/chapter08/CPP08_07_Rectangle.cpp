/*
 * rectangle.cpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#include "CPP08_07_Rectangle.hpp"

#include <iostream>
using namespace std;
Rectangle::Rectangle(void) :
		width(0), height(0) {
	cout << "Rectangle(void)" << endl;
}
Rectangle::Rectangle(double width, double height) :
		width(width), height(height) {
	cout << "Rectangle(double width, double height)" << endl;
}

Rectangle::Rectangle(const Rectangle &other) :
		width(other.width), height(other.height) {
	cout << "Rectangle(const Rectangle &other)" << endl;
}

Rectangle& Rectangle::operator =(const Rectangle &other) {
	cout << "operator =(const Rectangle &other)" << endl;
	if (this != &other) {
		this->width = other.width;
		this->height = other.height;
	}
	return *this;
}
void setData(Rectangle &rect, double width, double height) {
	rect.width = width;
	rect.height = height;
}
ostream& operator<<(ostream &output, Rectangle &rect) {
	output << "Rectangle[width=";
	output << rect.width;
	output << ",height=";
	output << rect.height;
	output << ",area()=";
	output << rect.area();
	output << ",perimeter()=";
	output << rect.perimeter();
	output << "]";
	return output;
}

Rectangle::~Rectangle() {
	cout << "~Rectangle()" << endl;
}
double Rectangle::area() {
	return width * height;
}
double Rectangle::perimeter() {
	return (width + height) * 2;
}

