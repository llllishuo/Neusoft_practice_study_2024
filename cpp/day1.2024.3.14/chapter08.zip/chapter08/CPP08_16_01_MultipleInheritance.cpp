//============================================================================
// Name        : CPP08_12_MultipleInheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
using namespace std;
class F1 {
protected:
	string name;
public:
	F1(string name) : name(name) {}
	void printName() {
		cout << name << endl;
	}
};
class F2 {
protected:
	int age;
public:
	F2(int age) : age(age) {}
	void printAge() {
		cout << age << endl;
	}
};
class S: public F1, public F2 {
public:
	S(string name, int age) :
			F1(name), F2(24) {
	}
};
int main() {
	S s("Tom", 28);
	s.printName();
	s.printAge();
	return 0;
}
