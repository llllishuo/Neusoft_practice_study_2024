//============================================================================
// Name        : CPP08_14_NestedClass.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
using namespace std;
class Outer {
	string name;
public:
	Outer(string);
	string getName();
	class Inner {
		string name;
	public:
		Inner(string);
		string getName();
	};
};
Outer::Outer(string name) :
		name(name) {
}
string Outer::getName() {
	return name;
}
Outer::Inner::Inner(string name) :
		name(name) {
}
string Outer::Inner::getName() {
	return name;
}
int main() {
	Outer outer("Tom");
	cout << outer.getName() << endl;
	Outer::Inner inner("John");
	cout << inner.getName() << endl;
	return 0;
}
