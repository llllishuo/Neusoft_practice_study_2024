//============================================================================
// Name        : CPP08_03_Constructor.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP08_07_Rectangle.hpp"
using namespace std;
inline int max(int x, int y) {
	return (x > y) ? x : y;
}
int main() {
	cout << max(9, 8) << endl;
	Rectangle rect1;
	rect1.setWidth(8);
	rect1.setHeight(6);
	cout << "rect1 = " << rect1 << endl;
	return 0;
}
