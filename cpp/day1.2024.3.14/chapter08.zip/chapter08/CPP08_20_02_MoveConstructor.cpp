//============================================================================
// Name        : CPP_12_01_AutoPtr.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstring>
#include <utility>
using namespace std;
class String {
private:
	char *cptr = nullptr;
public:
	String() { //默认构造函数
		cout << "String()" << endl;
	}
	String(const char *str) { //cstring构造函数
		cout << "String(const char *str)" << endl;
		cptr = new char[strlen(str) + 1]();
		strcpy(cptr, str);
	}
	String(const String &str) { //拷贝构造函数
		cout << "String(const String &str)" << endl;
		cptr = new char[strlen(str.cptr) + 1]();
		strcpy(cptr, str.cptr);
	}
	String& operator =(const String &str) { //赋值函数
		cout << "String& operator =(const String &str)" << endl;
		if (cptr) {
			delete[] cptr;
			cptr = nullptr;
		}
		cptr = new char[strlen(str.cptr) + 1]();
		strcpy(cptr, str.cptr);
		return *this;
	}
	String(String &&str) { //移动拷贝函数
		cout << "String(const String &&str)" << endl;
		cptr = str.cptr;
		str.cptr = nullptr;
	}
	String& operator =(String &&str) { //移动赋值函数
		cout << "String& operator =(const String &&str)" << endl;
		if (cptr) {
			delete cptr;
			cptr = nullptr;
		}
		cptr = str.cptr;
		str.cptr = nullptr;
		return *this;
	}
	friend ostream& operator<<(ostream &output, String &str) {
		if (str.cptr)
			output << str.cptr;
		return output;
	}
	friend String operator+(String &str1, String &str2) {
		cout << "friend String operator+(String &str1, String &str2)" << endl;
		char *ptr = new char[strlen(str1.cptr) + strlen(str2.cptr) + 1]();
		strcpy(ptr, str1.cptr);
		strcat(ptr, str2.cptr);
		return String(ptr);
	}
	~String() {
		cout << "~String()" << endl;
		cout << cptr << endl;
		if (cptr) {
			delete cptr;
		}
	}
};
String func() {
	String str3;
	String str1("Apple");
	String str2("Banana");
	str3 = str1 + str2;
	return str3;
}
int main() {//str2.cptr = str1.cptr;str1.cptr=nullptr;
	String str1 = "Hello world";
	String str2((String&&)str1);
	cout << "str1=" << str1 << endl;
	cout << "str2=" << str2 << endl;

	String str3 = "Apple";
	String str4 = "Banana";
	//tempStr.cptr = str3.cptr;str3.cptr=nullptr;
	//str3.cptr=str4.cptr;str4.cptr=nullptr;
	//str4.cptr=tempStr.cptr ;tempStr.cptr=nullptr;
	String tempStr = (String&&)str3;
	str3 = (String&&)str4;
	str4 = (String&&)tempStr;
	cout << "str3=" << str3 << endl;
	cout << "str4=" << str4 << endl;


//	String str1 = "Hello world";
//	cout << str1 << endl;
//	String str2 = func();
//	cout << str2 << endl;
	return 0;
}

