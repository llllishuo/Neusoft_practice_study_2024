/*
 * rectangle.cpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#include "CPP08_03_Rectangle.hpp"
#include <iostream>
using namespace std;
Rectangle::Rectangle() {
	cout << "Rectangle()" << endl;
	width = 0;
	height = 0;
}
Rectangle::Rectangle(double width, double height) {
	cout << "Rectangle(double width, double height)" << endl;
	this->width = width;
	this->height = height;
}
Rectangle::~Rectangle() {
	cout << "~Rectangle()" << endl;
}
double Rectangle::area() {
	return width * height;
}
double Rectangle::perimeter() {
	return (width + height) * 2;
}

