//============================================================================
// Name        : CPP_HR.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstring>
#include <string>
using namespace std;
class Rectangle {
private:
	double width;
	double height;
public:
	Rectangle(double width, double height) :
			width(width), height(height) {
	}
	operator int() {
		return width + height;
	}
	operator string() {
		char str[64];
		sprintf(str, "Rectangle[width=%f,height=%f]", width, height);
		return string(str);
	}
	~Rectangle() {
	}
};
int main() {
	Rectangle rect(3, 4);
	int i = rect;
	cout << i << endl;
	string str = rect;
	cout << str << endl;
	return 0;
}
