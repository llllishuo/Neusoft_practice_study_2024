//============================================================================
// Name        : CPP08_10_Inheritance.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "CPP08_14_Rectangle.hpp"
#include "CPP08_14_Ellipse.hpp"
int main() {
	{
		Shape *shape = new Rectangle(8, 6);
		cout << typeid(*shape).name() << endl;
		cout << "Is Rectangle ? " << boolalpha;
		cout << (typeid(*shape) == typeid(Rectangle)) << endl;
		cout << "Is Shape ? " << boolalpha;
		cout << (typeid(*shape) == typeid(Shape)) << endl;
		delete shape;
	}
	cout << endl;
	{
		Shape *shape = new Ellipse(4.3, 3.6);
		cout << typeid(*shape).name() << endl;
		cout << "Is Ellipse ? " << boolalpha;
		cout << (typeid(*shape) == typeid(Ellipse)) << endl;
		cout << "Is Shape ? " << boolalpha;
		cout << (typeid(*shape) == typeid(Shape)) << endl;
		delete shape;
	}
	return 0;
}
