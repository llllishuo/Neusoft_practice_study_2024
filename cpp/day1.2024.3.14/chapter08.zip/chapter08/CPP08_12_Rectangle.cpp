/*
 * rectangle.cpp
 *
 *  Created on: 2021年8月2日
 *      Author: xiaojf
 */

#include "CPP08_12_Rectangle.hpp"

#include <iostream>
using namespace std;
Rectangle::Rectangle(double width, double height) :
		width(width), height(height) {
	cout << "Rectangle::Rectangle(double width, double height)" << endl;
}
Rectangle::Rectangle(const Rectangle &other) :
		width(other.width), height(other.height) {
	cout << "Rectangle::Rectangle(const Rectangle &other)" << endl;
}
Rectangle::~Rectangle() {
	cout << "Rectangle::~Rectangle()" << endl;
}
Rectangle& Rectangle::operator =(const Rectangle &other) {
	cout << "Rectangle::operator =(const Rectangle &other)" << endl;
	if (this != &other) {
		this->width = other.width;
		this->height = other.height;
	}
	return *this;
}
string Rectangle::toString() {
	string str;
	str += "Rectangle[";
	str += "center=";
	str += center.toString();
	str += ",width=";
	str += to_string(width);
	str += ",height=";
	str += to_string(height);
	str += ",area()=";
	str += to_string(area());
	str += ",perimeter()=";
	str += to_string(perimeter());
	str += "]";

	return str;
}

ostream& operator<<(ostream &output, Rectangle &rect) {
	output << rect.toString();
	return output;
}
double Rectangle::area() {
	return width * height;
}
double Rectangle::perimeter() {
	return (width + height) * 2;
}

