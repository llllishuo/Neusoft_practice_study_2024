//============================================================================
// Name        : CPP05_10_Static.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void func();
void globalVar();
void staticGlobalVar();
void staticLocalVar();
int main() {
	func();
	cout << endl;
	for (int i = 0; i < 3; i++)
		globalVar();
	cout << endl;
	for (int i = 0; i < 3; i++)
		staticGlobalVar();
	cout << endl;
	for (int i = 0; i < 3; i++)
		staticLocalVar();
	return 0;
}
