//============================================================================
// Name        : CPP05_04_02_FuncOverload.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void func(int v1, int v2, int v3 = 99) {
	cout << "func(int v1, int v2, int v3 = 99)" << endl;
}
void func(int v1, int v2) {
	cout << "func(int v1, int v2)" << endl;
}
int main() {
	func(77, 88);
	return 0;
}
