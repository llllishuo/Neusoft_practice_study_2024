/*
 * shape.cpp
 *
 *  Created on: 2021年3月14日
 *      Author: xiaojf
 */
#include "CPP05_03_Shape.hpp"
double cubicVolume(double length, double width, double height) {
	return length * rectangleArea(width, height);
}
double rectangleArea(double width, double height) {
	return width * height;
}

