//============================================================================
// Name        : CPP05_02_FuncDeclaration.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
double rectangleArea(double width, double height = 1.5);
int main() {
	double width = 9, height = 6;
	cout << rectangleArea(width, height) << endl;
	cout << rectangleArea(width) << endl;
	return 0;
}
double rectangleArea(double width, double height = 1.5) {
	return width * height;
}
