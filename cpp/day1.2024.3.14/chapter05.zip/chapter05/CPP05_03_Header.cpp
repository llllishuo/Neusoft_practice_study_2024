//============================================================================
// Name        : CPP05_03_Header.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "CPP05_03_Shape.hpp"
using namespace std;

int main() {
	double width = 9, height = 6;
	cout << rectangleArea(width, height) << endl;
	cout << rectangleArea(width) << endl;
	double length = 10;
	cout << cubicVolume(length, width, height) << endl;
	return 0;
}
