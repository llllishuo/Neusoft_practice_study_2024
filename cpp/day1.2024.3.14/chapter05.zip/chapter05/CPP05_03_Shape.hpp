/*
 * shape.hpp
 *
 *  Created on: 2021年3月14日
 *      Author: xiaojf
 */

#ifndef CPP05_03_SHAPE_HPP_
#define CPP05_03_SHAPE_HPP_
double rectangleArea(double width, double height = 1.5);
double cubicVolume(double length, double width, double height);
#endif /* CPP05_03_SHAPE_HPP_ */
