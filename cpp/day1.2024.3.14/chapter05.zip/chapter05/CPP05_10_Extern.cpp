//============================================================================
// Name        : CPP05_12_Extern.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	extern int var;
	cout << "var = " << var << endl;
	return 0;
}
