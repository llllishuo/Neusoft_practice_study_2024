//============================================================================
// Name        : CPP_05_11_Inline.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int max(int v1, int v2);
int main() {
	int v1 = 10, v2 = 90;
	cout << "max(" << v1 << " , " << v2 << ") = ";
	cout << max(v1, v2) << endl;
	return 0;
}
inline int max(int v1, int v2) {
	return v1 > v2 ? v1 : v2;
}
