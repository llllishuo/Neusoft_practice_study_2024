//============================================================================
// Name        : CPP05_06_FuncPointer.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int intAdd(int v1, int v2) {
	return v1 + v2;
}
int intSub(int v1, int v2) {
	return v1 - v2;
}
int intMul(int v1, int v2) {
	return v1 * v2;
}
int intDiv(int v1, int v2) {
	return v1 / v2;
}
int (* action(char *act))(int, int) {
	if (strcmp(act, "add") == 0)
		return intAdd;
	else if (strcmp(act, "sub") == 0)
		return intSub;
	else if (strcmp(act, "mul") == 0)
		return intMul;
	else if (strcmp(act, "div") == 0)
		return intDiv;
	else
		return NULL;
}
int main() {
	int v1 = 200, v2 = 150;
	int (*oper)(int, int) = intSub;
	cout << oper(v1, v2) << endl;
	oper = action("mul");
	cout << oper(v1, v2) << endl;
	return 0;
}
