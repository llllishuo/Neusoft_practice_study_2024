//============================================================================
// Name        : CPP05_07_VarScope.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int var = 100;
int main() {
	cout << var << endl;
	{
		int var = 200;
		cout << var << endl;
		{
			int var = 300;
			cout << var << endl;
		}
		cout << var << endl;
	}
	cout << var << endl;
	for (int i = 0; i < 10; i++) {
		cout << i << " ";
	}
	return 0;
}
