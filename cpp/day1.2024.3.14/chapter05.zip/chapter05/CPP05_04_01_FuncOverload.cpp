//============================================================================
// Name        : CPP05_04_FuncOverload.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int sum(int v1, int v2=10) {
	cout << "sum(int , int) 被调用" << endl;
	return v1 + v2;
}
double sum(double v1, double v2) {
	cout << "sum(double , double) 被调用" << endl;
	return v1 + v2;
}
double sum(int v1, double v2) {
	cout << "sum(int , double) 被调用" << endl;
	return v1 + v2;
}
double sum(double v1, int v2) {
	cout << "sum(double , int) 被调用" << endl;
	return v1 + v2;
}
int main() {

	cout << sum(3, 4) << endl;
	cout << sum(3.5, 4.6) << endl;
	cout << sum(3, 4.6) << endl;
	cout << sum(3.5, 4) << endl;
	return 0;
}
