//============================================================================
// Name        : CPP05_05_ParameterPassing.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int callByValue(int v) {
	return ++v;
}
int callByPointer(int *pv) {
	return ++(*pv);
}
int callByReference(int &v) {
	return ++v;
}
int main() {
	int v = 100;
	cout << v << " , " << callByValue(v) << " , " << v << endl;
	cout << v << " , " << callByPointer(&v) << " , " << v << endl;
	cout << v << " , " << callByReference(v) << " , " << v << endl;
	return 0;
}
