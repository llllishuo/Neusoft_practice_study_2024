
int var = 100;

