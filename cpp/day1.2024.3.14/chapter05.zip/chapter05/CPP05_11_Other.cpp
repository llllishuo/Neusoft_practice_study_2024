#include <iostream>
using namespace std;
int var01 = 1000;
int var02;
static int var03 = 3000;
static int var04;
/*static*/void func() {
	int num = 100;
	cout << "num = " << num << endl;
	char str1[] = "A. Hello String";
	char str2[] = "A. Hello String";
	cout << "str1 == str2 = " << (str1 == str2);
	cout << endl;
	char *str3 = "B. Hello String";
	char *str4 = "B. Hello String";
	cout << "str3 == str4 = " << (str3 == str4);
	cout << endl;

}
void globalVar() {
	var01++, var02++;
	cout << "globalVar : var01 = ";
	cout << var01 << endl;
	cout << "globalVar : var02 = ";
	cout << var02 << endl;
}
void staticGlobalVar() {
	var03++, var04++;
	cout << "staticGlobalVar : var03 = ";
	cout << var03 << endl;
	cout << "staticGlobalVar : var04 = ";
	cout << var04 << endl;
}
void staticLocalVar() {
	static int var05 = 5000;
	static int var06;
	var05++, var06++;
	cout << "staticLocalVar : var05 = ";
	cout << var05 << endl;
	cout << "staticLocalVar : var06 = ";
	cout << var06 << endl;
}

