//============================================================================
// Name        : CPP05_09_Varargs.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
double sumDouble1(int num, ...) {
	double sum = 0.0;
	va_list valist;
	va_start(valist, num);
	for (int i = 0; i < num; i++) {
		sum += va_arg(valist, double);
	}
	va_end(valist);
	return sum;
}
double sumDouble2(double val, ...) {
	double sum = 0.0;
	va_list valist;
	va_start(valist, val);
	sum += val;
	while ((val = va_arg(valist, double)) != 0.0) {
		sum += val;
	}
	va_end(valist);
	return sum;
}
int main() {
	cout << "sumDouble1(2, 2.0, 4.0) = ";
	cout << sumDouble1(2, 2.0, 4.0) << endl;
	cout << "sumDouble1(3, 1.5, 4.7, 7.2) = ";
	cout << sumDouble1(3, 1.5, 4.7, 7.2) << endl;
	cout << "sumDouble2(2.6, 2.4, 0.0) = ";
	cout << sumDouble2(2.6, 2.4, 0.0) << endl;
	cout << "sumDouble2(3.0, 1.5, 4.7, 0.0) = ";
	cout << sumDouble2(3.0, 1.5, 4.7, 0.0) << endl;
	return 0;
}
