//============================================================================
// Name        : CPP05_01_FuncDefinition.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
double rectangleArea(double width, double height = 1.5) {
	return width * height;
}

int main() {
	double width = 9, height = 6;
	cout << rectangleArea(width, height) << endl;
	cout << rectangleArea(width) << endl;
	return 0;
}
