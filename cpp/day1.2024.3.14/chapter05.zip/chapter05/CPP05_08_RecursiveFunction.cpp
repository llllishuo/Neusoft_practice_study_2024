//============================================================================
// Name        : CPP05_08_RecursiveFunction.cpp
// Author      : 肖俊峰
// Version     :
// Copyright   : 版权所有，仅供教学学习使用
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
unsigned long factorial(unsigned long n) {
	if (n == 0)
		return 1;
	else
		return n * factorial(n - 1);
}
int main() {
	unsigned long n = 20;
	cout << "factorial(" << n << ")=" << factorial(n);
	return 0;
}
